//
//  CollectionApp.swift
//  Collection
//
//  Created by Ryan King on 5/4/24.
//

import SwiftUI

@main
struct CollectionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
